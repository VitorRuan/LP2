﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {

            Horista objHorista = new Horista();

            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeMpregado = txtNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntradaEMpresa.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHora.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);
            if (rbtnSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';

            MessageBox.Show("Matricula: " + objHorista.Matricula + "\n" + "Nome: " + objHorista.NomeMpregado + "\n" +
                "Data Entrada: " + objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" + "Salário Bruto: " + objHorista.SalarioBruto().ToString("N2") + "\n" +
                "TEmpo Empresa (dias): " + objHorista.TempoTrabalho() + "\n" + objHorista.VerificaHome());
        }
    }
}
